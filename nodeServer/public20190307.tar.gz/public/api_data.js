define({ "api": [
  {
    "type": "post",
    "url": "http://114.116.122.116:8092/api/v2.0/chatbot",
    "title": "小七智答",
    "version": "2.0.0",
    "name": "chatbot",
    "group": "Chatbot",
    "parameter": {
      "fields": {
        "请求参数": [
          {
            "group": "请求参数",
            "type": "string",
            "allowedValues": [
              "\"中文\""
            ],
            "optional": false,
            "field": "question",
            "description": "<p>(必填)咨询的问题</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "请求样例form-data:",
          "content": "{\n\"question\": \"你是谁\"\n}",
          "type": "from-data"
        }
      ]
    },
    "success": {
      "fields": {
        "返回参数": [
          {
            "group": "返回参数",
            "type": "string",
            "optional": false,
            "field": "answer",
            "description": "<p>回复的答案</p>"
          },
          {
            "group": "返回参数",
            "type": "string",
            "optional": false,
            "field": "question",
            "description": "<p>咨询的问题</p>"
          },
          {
            "group": "返回参数",
            "type": "string",
            "optional": false,
            "field": "msg",
            "description": "<p>提示信息:数据存储状态反馈</p>"
          },
          {
            "group": "返回参数",
            "type": "string",
            "optional": false,
            "field": "error_code",
            "description": "<p>异常码</p>"
          },
          {
            "group": "返回参数",
            "type": "string",
            "optional": false,
            "field": "error_msg",
            "description": "<p>异常信息描述,辅助用户排查和解决异常</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "请求正常:",
          "content": "{\n\"data\":{\n\"answer\":\"我是小通\",\n\"question\":\"你是谁\"\n},\n\"msg\":\"数据库保存成功\"\n}",
          "type": "json"
        },
        {
          "title": "请求正常:",
          "content": "{\n\"data\":{\n\"answer\":\"我是小通\",\n\"question\":\"你是谁\"\n},\n\"msg\":\"数据库已存在,不重复存储\"\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "请求异常:",
          "content": "{\n\"error_code\":250,\n\"error_msg\":\"输入为空或输入问题过长\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "./views.py",
    "groupTitle": "Chatbot"
  },
  {
    "type": "post",
    "url": "http://114.116.122.116:8096/api/v1.0/couplets",
    "title": "AI对联",
    "version": "1.0.0",
    "name": "chatbot",
    "group": "Couplets",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "\"中文\""
            ],
            "optional": false,
            "field": "first_couplet",
            "description": "<p>(必填)上联</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "请求样例form-data:",
          "content": "{\n\"first_couplet\": \"仰望星空\"\n}",
          "type": "form-data"
        }
      ]
    },
    "success": {
      "fields": {
        "返回参数": [
          {
            "group": "返回参数",
            "type": "string",
            "optional": false,
            "field": "second_couplet",
            "description": "<p>下联</p>"
          },
          {
            "group": "返回参数",
            "type": "string",
            "optional": false,
            "field": "msg",
            "description": "<p>提示信息</p>"
          },
          {
            "group": "返回参数",
            "type": "string",
            "optional": false,
            "field": "error_code",
            "description": "<p>异常码</p>"
          },
          {
            "group": "返回参数",
            "type": "string",
            "optional": false,
            "field": "error_msg",
            "description": "<p>异常信息描述,辅助用户排查和解决异常</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "请求正常:",
          "content": "{\n\"data\":{\n\"first_couplet\": \"仰望星空\",\n\"second_couplet\": \"俯察陆海\"\n},\n\"msg\":\"请求成功\"\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "请求异常:",
          "content": "{\n\"error_code\":250,\n\"error_msg\":\"输入为空或输入问题过长\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "./views.py",
    "groupTitle": "Couplets"
  },
  {
    "type": "post",
    "url": "http://114.116.122.116:8095/api/v1.0/image_object_detect/output_boxes",
    "title": "图像目标检测:返回坐标",
    "version": "1.0.0",
    "name": "image_object_detect_one",
    "group": "ImageObjectDetection",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "'*.png,*jpg,base64'"
            ],
            "optional": false,
            "field": "image",
            "description": "<p>(必填)上传的图像,支持*.png,*jpg和base64格式文件</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "请求样例json:",
          "content": "{\n\"image\": \"base64字符串或*.png,*jpg格式图像文件\"\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "fields": {
        "返回参数": [
          {
            "group": "返回参数",
            "type": "int",
            "optional": false,
            "field": "bboxes",
            "description": "<p>目标标注框坐标列表,ymin,xmin,ymax,xmax</p>"
          },
          {
            "group": "返回参数",
            "type": "string",
            "optional": false,
            "field": "classes",
            "description": "<p>目标类别列表</p>"
          },
          {
            "group": "返回参数",
            "type": "string",
            "optional": false,
            "field": "height",
            "description": "<p>检测图片的高度</p>"
          },
          {
            "group": "返回参数",
            "type": "string",
            "optional": false,
            "field": "width",
            "description": "<p>检测图片的宽度</p>"
          },
          {
            "group": "返回参数",
            "type": "string",
            "optional": false,
            "field": "scores",
            "description": "<p>目标评估分数</p>"
          },
          {
            "group": "返回参数",
            "type": "string",
            "optional": false,
            "field": "msg",
            "description": "<p>提示信息</p>"
          },
          {
            "group": "返回参数",
            "type": "string",
            "optional": false,
            "field": "error_code",
            "description": "<p>异常码</p>"
          },
          {
            "group": "返回参数",
            "type": "string",
            "optional": false,
            "field": "error_msg",
            "description": "<p>异常信息描述,辅助用户排查和解决异常</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "请求正常:",
          "content": "{\n    \"data\": {\n        \"bboxes\": [\n            [\n                0.26285913586616516,\n                0.504441499710083,\n                0.9302585124969482,\n                0.9774720668792725\n            ],\n            [\n                0.2221844494342804,\n                0.047912776470184326,\n                0.8876439332962036,\n                0.46481698751449585\n            ],\n            [\n                0.20634159445762634,\n                0.10370054841041565,\n                0.8832091093063354,\n                0.8953887224197388\n            ],\n            [\n                0.1110549196600914,\n                0.19933685660362244,\n                0.26660358905792236,\n                0.417845219373703\n            ],\n            [\n                0.13155044615268707,\n                0.7867240905761719,\n                0.2800493836402893,\n                0.991187572479248\n            ]\n        ],\n        \"classes\": [\n            9,\n            9,\n            11,\n            9,\n            9\n        ],\n        \"scale\": {\n            \"height\": 577,\n            \"width\": 587\n        },\n        \"scores\": [\n            0.9990853071212769,\n            0.9966327548027039,\n            0.8704712390899658,\n            0.7775992751121521,\n            0.5132179260253906\n        ]\n    },\n    \"msg\": \"检测完成\"\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "请求异常:",
          "content": "{\n\"error_code\":250,\n\"error_msg\":\"检查文件类型,只支持*.png, *.jpg和base64\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "./views.py",
    "groupTitle": "ImageObjectDetection"
  },
  {
    "type": "post",
    "url": "http://114.116.122.116:8095/api/v1.0/image_object_detect/output_base64",
    "title": "图像目标检测:返回base64",
    "version": "1.0.0",
    "name": "image_object_detect_two",
    "group": "ImageObjectDetection",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "'*.png,*jpg,base64'"
            ],
            "optional": false,
            "field": "image",
            "description": "<p>(必填)上传的图像,支持*.png,*jpg和base64格式文件</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "请求样例json:",
          "content": "{\n\"image\": \"base64字符串或*.png,*jpg格式图像文件\"\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "fields": {
        "返回参数": [
          {
            "group": "返回参数",
            "type": "string",
            "optional": false,
            "field": "detect_result",
            "description": "<p>检测结果,图片base64编码</p>"
          },
          {
            "group": "返回参数",
            "type": "string",
            "optional": false,
            "field": "msg",
            "description": "<p>提示信息</p>"
          },
          {
            "group": "返回参数",
            "type": "string",
            "optional": false,
            "field": "error_code",
            "description": "<p>异常码</p>"
          },
          {
            "group": "返回参数",
            "type": "string",
            "optional": false,
            "field": "error_msg",
            "description": "<p>异常信息描述,辅助用户排查和解决异常</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "请求正常:",
          "content": "{\n\"data\":{\n\"detect_result\":\"base64字符串\"\n},\n\"msg\":\"检测完成\"\t\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "请求异常:",
          "content": "{\n\"error_code\":250,\n\"error_msg\":\"检查文件类型,只支持*.png, *.jpg和base64\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "./views.py",
    "groupTitle": "ImageObjectDetection"
  },
  {
    "type": "post",
    "url": "http://114.116.122.116:8093/api/v2.0/image_style_trans",
    "title": "图像风格迁移",
    "version": "2.0.0",
    "name": "image_style_trans",
    "group": "ImageStyleTrans",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "allowedValues": [
              "'*.png,*jpg,base64'"
            ],
            "optional": false,
            "field": "image",
            "description": "<p>(必填)上传的图像文件,支持*.png,*jpg和base64格式文件</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "modelname",
            "description": "<p>(必须)供选择的图像风格,输出对应风格的图像,可选风格:cubist.ckpt-done,denoised_starry.ckpt-done,feathers.ckpt-done,mosaic.ckpt-done,scream.ckpt-done,udnie.ckpt-done,wave.ckpt-done</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "请求样例json/form-data:",
          "content": "{\n\"image\": \"base64字符串或*.png,*jpg格式图像文件\",\n\"modelname\": \"cubist.ckpt-done\"\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "fields": {
        "返回参数": [
          {
            "group": "返回参数",
            "type": "string",
            "optional": false,
            "field": "trans_image",
            "description": "<p>转换风格的图片,格式为base64</p>"
          },
          {
            "group": "返回参数",
            "type": "string",
            "optional": false,
            "field": "msg",
            "description": "<p>转换提示信息</p>"
          },
          {
            "group": "返回参数",
            "type": "string",
            "optional": false,
            "field": "error_code",
            "description": "<p>异常码</p>"
          },
          {
            "group": "返回参数",
            "type": "string",
            "optional": false,
            "field": "error_msg",
            "description": "<p>异常信息描述,辅助用户排查和解决异常</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "请求正常:",
          "content": "{\n\"data\":{\n\"trans_image\":\"base64字符串\"\n},\n\"msg\":\"转换成功\"\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "请求异常:",
          "content": "{\n\"error_code\":250,\n\"error_msg\":\"图像格式错误\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "./views.py",
    "groupTitle": "ImageStyleTrans"
  },
  {
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "optional": false,
            "field": "varname1",
            "description": "<p>No type.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "varname2",
            "description": "<p>With type.</p>"
          }
        ]
      }
    },
    "type": "",
    "url": "",
    "version": "0.0.0",
    "filename": "./static/docs/main.js",
    "group": "_home_xdq_xinPrj_python_web_flask_prj_ai_api_doc_static_docs_main_js",
    "groupTitle": "_home_xdq_xinPrj_python_web_flask_prj_ai_api_doc_static_docs_main_js",
    "name": ""
  }
] });
