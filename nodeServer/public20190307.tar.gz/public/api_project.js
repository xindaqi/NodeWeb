define({
  "name": "AILab智能应用接口文档",
  "version": "1.0.0",
  "description": "兴海物联人工智能团队基于AI智能算法开发的智能应用开放接口手册",
  "title": "REST API",
  "url1": "http://localhost:8090",
  "url2": "http://localhost:8091",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2019-03-07T06:08:50.081Z",
    "url": "http://apidocjs.com",
    "version": "0.17.7"
  }
});
